export interface MailModuleOptions {
  apiKey: string;
  secret: string;
  senderAddress: string;
  language: string;
}
