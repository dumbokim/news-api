export class CreateUserDto {
  id: string;

  password: string;

  name: string;

  email: string;
}
