export class LoginDto {
  id: string;
  password: string;
}
