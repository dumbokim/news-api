export class VerifyTokenResponseDto {
  name: string;
  id: string;
  email: string;
}
