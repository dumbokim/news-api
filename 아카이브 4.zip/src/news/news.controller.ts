import { Controller } from '@nestjs/common';

@Controller('news')
export class NewsController {}
